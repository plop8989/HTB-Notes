---

---

# 6/15/2025

==Finish NFS-SMTP==

- [x] NFS
- [ ] DNS
- [ ] SMTP
### Non-Main goals

- [ ] Put books into google drive
- [ ] Do Planning box on htb

---
# 6/17/2025

==Finish 6/15 goals & more==

- Make sure to mark previous unfinished goals

- [ ] Install Endeavor&hHyDE on new laptop
- [ ] Shrink partition for endeavor 
- [x] Install kali & I3 on newly freed space

### Non-Main Goals

- [ ] Start HTB Planning Box