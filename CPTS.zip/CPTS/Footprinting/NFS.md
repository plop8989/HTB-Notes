
# What is it

Network File System (NFS) is a network file system that has the same purpose as SMB.

==It uses completely different protocols than SMB thus its unable to communicate with SMB.==

==It is meant for Linux and Unix systems==

---
# Versions and their changes

![[NFS Versions.png]]NFSv4.1 (files can be .pNFS extension) ==uses only one TCP or UDP port 2049== to run the service which simplifies the use of the protocol across firewalls.

NFS is based on Open Network Computing Remote Procedure Call (ONC-RPC / SUN-RPC). ==This protocol is only exposed on TCP and UDP ports 111 which uses External Data Representation (XDR)==. 
NFS has ==NO AUTHENTICATION / AUTHORIZATION PROTOCOLS== so authentication is shifted to the RPC protocol's options.

---
# Configurations

NFS doesn't have as many options as FTP or SMB so it is simple to setup and configure. 
==/etc/exports== is the file that contains a table of physical filesystems on the NFS server accessible by the clients. ==This file shows the options it accepts thus showing us which options are available to us.== 

### Analyzing the NFS Exports Table

![[NFS Default Config.png|657x160]]

![[NFS Permissions.png|657x205]]

#### Dangerous Settings to look to exploit

![[Dangerous Settigns.png]]

---
# Footprinting The Service

When footprinting NFS, ==TCP 111 & 2049 are essential.== We can also gather info on the service and the host ==via RPC==

#### Scan of 111 & 2049 (TCP)

```python
sudo nmap 10.129.14.128 -p111,2049 -sV -sC

Starting Nmap 7.80 ( https://nmap.org ) at 2021-09-19 17:12 CEST
Nmap scan report for 10.129.14.128
Host is up (0.00018s latency).

PORT    STATE SERVICE VERSION
111/tcp open  rpcbind 2-4 (RPC #100000)
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|   100000  3,4          111/udp6  rpcbind
|   100003  3           2049/udp   nfs
|   100003  3           2049/udp6  nfs
|   100003  3,4         2049/tcp   nfs
|   100003  3,4         2049/tcp6  nfs
|   100005  1,2,3      41982/udp6  mountd
|   100005  1,2,3      45837/tcp   mountd
|   100005  1,2,3      47217/tcp6  mountd
|   100005  1,2,3      58830/udp   mountd
|   100021  1,3,4      39542/udp   nlockmgr
|   100021  1,3,4      44629/tcp   nlockmgr
|   100021  1,3,4      45273/tcp6  nlockmgr
|   100021  1,3,4      47524/udp6  nlockmgr
|   100227  3           2049/tcp   nfs_acl
|   100227  3           2049/tcp6  nfs_acl
|   100227  3           2049/udp   nfs_acl
|_  100227  3           2049/udp6  nfs_acl
2049/tcp open  nfs_acl 3 (RPC #100227)
MAC Address: 00:00:00:00:00:00 (VMware)
```

Nmap's ==rpcinfo== NSE script retrieves of all the running RPC services, names, descriptions, & the ports they use. It also lets us check if the target share is connected to the network on the required ports. For NFS, Nmap has some NSE scripts that can show us stuff like the contents of shares and its stats. ==--script "nfs*"==

```python
sudo nmap --script "nfs*" 10.129.14.128 -sV -p111,2049

Starting Nmap 7.80 ( https://nmap.org ) at 2021-09-19 17:37 CEST
Nmap scan report for 10.129.14.128
Host is up (0.00021s latency).

PORT     STATE SERVICE VERSION
111/tcp  open  rpcbind 2-4 (RPC #100000)
| nfs-ls: Volume /mnt/nfs
|   access: Read Lookup NoModify NoExtend NoDelete NoExecute
| PERMISSION  UID    GID    SIZE  TIME                 FILENAME
| rwxrwxrwx   65534  65534  4096  2021-09-19T15:28:17  .
| ??????????  ?      ?      ?     ?                    ..
| rw-r--r--   0      0      1872  2021-09-19T15:27:42  id_rsa
| rw-r--r--   0      0      348   2021-09-19T15:28:17  id_rsa.pub
| rw-r--r--   0      0      0     2021-09-19T15:22:30  nfs.share
|_
| nfs-showmount: 
|_  /mnt/nfs 10.129.14.0/24
| nfs-statfs: 
|   Filesystem  1K-blocks   Used       Available   Use%  Maxfilesize  Maxlink
|_  /mnt/nfs    30313412.0  8074868.0  20675664.0  29%   16.0T        32000
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|   100000  3,4          111/udp6  rpcbind
|   100003  3           2049/udp   nfs
|   100003  3           2049/udp6  nfs
|   100003  3,4         2049/tcp   nfs
|   100003  3,4         2049/tcp6  nfs
|   100005  1,2,3      41982/udp6  mountd
|   100005  1,2,3      45837/tcp   mountd
|   100005  1,2,3      47217/tcp6  mountd
|   100005  1,2,3      58830/udp   mountd
|   100021  1,3,4      39542/udp   nlockmgr
|   100021  1,3,4      44629/tcp   nlockmgr
|   100021  1,3,4      45273/tcp6  nlockmgr
|   100021  1,3,4      47524/udp6  nlockmgr
|   100227  3           2049/tcp   nfs_acl
|   100227  3           2049/tcp6  nfs_acl
|   100227  3           2049/udp   nfs_acl
|_  100227  3           2049/udp6  nfs_acl
2049/tcp open  nfs_acl 3 (RPC #100227)
MAC Address: 00:00:00:00:00:00 (VMware)
```

---
# What Next?

Once we discover the NFS service, it can be mounted on our local machine. 

1. Create empty folder for the NFS share to be mounted to
2. Show available NFS shares:
```python
showmount -e 10.129.14.128

Export list for 10.129.14.128:
/mnt/nfs 10.129.14.0/24
```
3. Mount the share
```python
~> mkdir target-NFS
~> sudo mount -t nfs 10.129.14.128:/ ./target-NFS/ -o nolock
~> cd target-NFS
~> tree .

.
└── mnt
    └── nfs
        ├── id_rsa
        ├── id_rsa.pub
        └── nfs.share

2 directories, 3 files
```
There we will have the chance to access the rights, usernames, and groups to whom the shown and viewable files belong. Once we have usernames, group names, UIDs, GUIDs, we can create them on our system and adapt them to the NFS share to view and modify the files
4. List Contents with User & Group Names or with UIDs and GUIDs
```python
~>ls -l mnt/nfs/

total 16
-rw-r--r-- 1 cry0l1t3 cry0l1t3 1872 Sep 25 00:55 cry0l1t3.priv
-rw-r--r-- 1 cry0l1t3 cry0l1t3  348 Sep 25 00:55 cry0l1t3.pub
-rw-r--r-- 1 root     root     1872 Sep 19 17:27 id_rsa
-rw-r--r-- 1 root     root      348 Sep 19 17:28 id_rsa.pub
-rw-r--r-- 1 root     root        0 Sep 19 17:22 nfs.share
```

```python
ls -n mnt/nfs/

total 16
-rw-r--r-- 1 1000 1000 1872 Sep 25 00:55 cry0l1t3.priv
-rw-r--r-- 1 1000 1000  348 Sep 25 00:55 cry0l1t3.pub
-rw-r--r-- 1    0 1000 1221 Sep 19 18:21 backup.sh
-rw-r--r-- 1    0    0 1872 Sep 19 17:27 id_rsa
-rw-r--r-- 1    0    0  348 Sep 19 17:28 id_rsa.pub
-rw-r--r-- 1    0    0    0 Sep 19 17:22 nfs.share
```

Unmounting;
```python
~> cd ../
~> sudo umount .target-NFS
```

## Important to note:

==If the 'root-squash' option is set, we cannot edit the backup.sh file even as root==

We can use NFS for further escalation. Example:
If we are in the system via SSH and want to read files from another folder that a specific user can read, we need to upload a shell to the NFS share that has the SUID of that user and run the shell via the SSH user.