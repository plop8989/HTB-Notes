# What is it

Domain Name System ==(DNS)== is a system for resolving computer names into IP addresses, it doesn't have a central database.

The info is spread over many thousands of name servers. There are 13 logical DNS servers but each is actually implemented by thousands of servers across the world, these are called physical instances. 

This is possible via a technology called Anycast routing. It allows multiple physical servers with different geographical locations to share the same IP address. 

When a DNS query is made to one of the 13 roots, Anycast directs it to the geographically closest physical instance.

As of 2022 there are 1955 physical instances.

==DNS servers translate domain names into IP addresses; controlling which server a user can reach via a particular domain==

==There are several types of DNS servers that are used worldwide==

| Type                         | Info                                                                                                                                                                                                                                                                                |
| ---------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| DNS Root Server              | Responsible for top-level domains (TLD). These are only requested if the name server doesn't respond. ==A root server is the central interface between users and content on the internet as it links domains and IPs.==The ==ICANN== coordinates the work of the root name servers. |
| Authoritative Nameserver     | Hold authority for a particular zone. Only answer queries from their area of responsibility. ==If it can't answer a client's query, the root name server takes over.==                                                                                                              |
| Non-authoritative Nameserver | ==Not responsible for a particular DNS zone==, they collect info on specific DNS zones via recursive or iterative querying.                                                                                                                                                         |
| Caching DNS Server           | Cache info from other name servers for a specified period. ==The authoritative name server determines the duration of this storage.==                                                                                                                                               |
| Forwarding Server            | All they do is forward queries to another DNS server.                                                                                                                                                                                                                               |
| Resolver                     | These are not Authoritative DNS Servers but ==perform name resolution locally in the computer or router==.                                                                                                                                                                          |

---
# Implementation in IT

==DNS is mainly unencrypted.== Devices one the WLAN can hack in and spy on DNS queries. To prevent this things like ==DNS over TLS (DoT)== or ==DNS over HTTPS (DOH)== are implemented. The network protocol ==DNSCrypt== also encrypts traffic between the computer and the name server. 

DNS doesn't just link PC names and IPs. It stores and outputs extra data about the services associated with a domain. Therefore, for example a DNS query can be used to determine which computer serves as the email server for the domain or what the domain's name servers are called. 

![[DNS map.png]]

---
# DNS Records

Different DNS records are used for queries, all have various tasks. Separate entries exist for different functions since we can set up mail servers and other servers for a domain.
![[DNS Records.png]]

==The SOA record is located in a domain's zone file and specifies who is responsible for its operation and how it's info is managed.==

```python
~> dig soa www.inlanefreight.com

; <<>> DiG 9.16.27-Debian <<>> soa www.inlanefreight.com
;; global options: +cmd
;; Got answer:
;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 15876
;; flags: qr rd ra; QUERY: 1, ANSWER: 0, AUTHORITY: 1, ADDITIONAL: 1

;; OPT PSEUDOSECTION:
; EDNS: version: 0, flags:; udp: 512
;; QUESTION SECTION:
;www.inlanefreight.com.         IN      SOA

;; AUTHORITY SECTION:
inlanefreight.com.      900     IN      SOA     ns-161.awsdns-20.com. awsdns-hostmaster.amazon.com. 1 7200 900 1209600 86400

;; Query time: 16 msec
;; SERVER: 8.8.8.8#53(8.8.8.8)
;; WHEN: Thu Jan 05 12:56:10 GMT 2023
;; MSG SIZE  rcvd: 128
```

==The dot (.) is replaced by an at sign (@) in the email address. In this case, the email address of the administrator is== awsdns-hostmaster@amazon.com

---
# Default Configuration

All DNS servers work with 3 different types of config files:
1. Local DNS config files
2. zone files
3. reverse name resolution files

==Bind9==  is a server software used on Linux based distros. It's local config file ==(named.conf)== has 2 sections; options for general settings, and the zone entries for individual domains. The local config files are usually: 
 - named.conf.local
 - named.conf.options
 - named.conf.log

It contains the associated Request for Comments (==RFC==) where the server can be customized to our needs and domain structure with zones for each domain.

The file named.conf is split into multiple options that control the behavior of the name server.

### Global VS Zone Options
 - Global options are general and affect all zones.
 - Zone options only affect the zone it is assigned to.

Options not listed in named.conf have default values.
If an option is both global and zone-specific, the zone option takes precedence. 

Inside named.conf.local zones can be defined. Zones are split into individual files which for most cases, each zone is meant for a single domain. There are many options that can extend or reduce the functionality.

A zone file is at text file that describes a DNS zone with the BIND file format. There must be precisely one SOA record and at least one NS record. The SOA resource record is usually at the start of a zone file. ==A syntax error usually results in the zone file being unusable and the name server acts as if the zone doesn't exist. It responds to DNS queries with a SERVFAIL error==

---

# Zone files


```zsh
cat /etc/bind/db.domain.com

;
; BIND reverse data file for local loopback interface
;
$ORIGIN domain.com
$TTL 86400
@     IN     SOA    dns1.domain.com.     hostmaster.domain.com. (
                    2001062501 ; serial
                    21600      ; refresh after 6 hours
                    3600       ; retry after 1 hour
                    604800     ; expire after 1 week
                    86400 )    ; minimum TTL of 1 day

      IN     NS     ns1.domain.com.
      IN     NS     ns2.domain.com.

      IN     MX     10     mx.domain.com.
      IN     MX     20     mx2.domain.com.

             IN     A       10.129.14.5

server1      IN     A       10.129.14.5
server2      IN     A       10.129.14.7
ns1          IN     A       10.129.14.2
ns2          IN     A       10.129.14.3

ftp          IN     CNAME   server1
mx           IN     CNAME   server1
mx2          IN     CNAME   server2
www          IN     CNAME   server2
```

A DNS server needs a reverse lookup file for an IP address to be resolved from the ==Fully Qualified Domain Name (FQDN).== In this file, the computer name (FQDN) is assigned to the last octet of an IP, which corresponds to the respective host via a PTR record. PTR records are responsible for the reverse translation of IP addresses into names.

### Reverse Name Resolution Zone Files
```zsh
cat /etc/bind/db.10.129.14

;
; BIND reverse data file for local loopback interface
;
$ORIGIN 14.129.10.in-addr.arpa
$TTL 86400
@     IN     SOA    dns1.domain.com.     hostmaster.domain.com. (
                    2001062501 ; serial
                    21600      ; refresh after 6 hours
                    3600       ; retry after 1 hour
                    604800     ; expire after 1 week
                    86400 )    ; minimum TTL of 1 day

      IN     NS     ns1.domain.com.
      IN     NS     ns2.domain.com.

5    IN     PTR    server1.domain.com.
7    IN     MX     mx.domain.com.
```

---
# Dangerous Settings

There are many ways to attack a DNS server. With things as important as DNS, functionality is prioritized over security. The main vulnerabilities with DNS servers are misconfigurations.
![[DNS Dangerous Settings.png]]

---
# Footprinting The Service

Footprinting of DNS servers is done as a result of the requests we send. First of all, the DNS server can be queried as to which other name servers are known. We do this using the NS record and the specification of the DNS server we want to query using the @ character. If there are other DNS servers, we can also use them and query the records. Other DNS servers may be configured differently and may be permanent for other zones.

---
# DIG - NS Query

```python
dig ns inlanefreight.htb @10.129.14.128

; <<>> DiG 9.16.1-Ubuntu <<>> ns inlanefreight.htb @10.129.14.128
;; global options: +cmd
;; Got answer:
;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 45010
;; flags: qr aa rd ra; QUERY: 1, ANSWER: 1, AUTHORITY: 0, ADDITIONAL: 2

;; OPT PSEUDOSECTION:
; EDNS: version: 0, flags:; udp: 4096
; COOKIE: ce4d8681b32abaea0100000061475f73842c401c391690c7 (good)
;; QUESTION SECTION:
;inlanefreight.htb.             IN      NS

;; ANSWER SECTION:
inlanefreight.htb.      604800  IN      NS      ns.inlanefreight.htb.

;; ADDITIONAL SECTION:
ns.inlanefreight.htb.   604800  IN      A       10.129.34.136

;; Query time: 0 msec
;; SERVER: 10.129.14.128#53(10.129.14.128)
;; WHEN: So Sep 19 18:04:03 CEST 2021
;; MSG SIZE  rcvd: 107
```

Sometimes you can query a DNS server's version using a class CHAOS query and type TXT. For this to work, the entry must exist on the DNS server. This can be done with the following command:
```python
dig CH TXT version.bind 10.129.120.85

; <<>> DiG 9.10.6 <<>> CH TXT version.bind
;; global options: +cmd
;; Got answer:
;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 47786
;; flags: qr aa rd; QUERY: 1, ANSWER: 1, AUTHORITY: 0, ADDITIONAL: 1

;; ANSWER SECTION:
version.bind.       0       CH      TXT     "9.10.6-P1"

;; ADDITIONAL SECTION:
version.bind.       0       CH      TXT     "9.10.6-P1-Debian"

;; Query time: 2 msec
;; SERVER: 10.129.120.85#53(10.129.120.85)
;; WHEN: Wed Jan 05 20:23:14 UTC 2023
;; MSG SIZE  rcvd: 101
```

We can use the option ==ANY== to view all available records. This will cause the server to show all available entries it is willing to disclose. Important to note that not all entries will be shown. 

---
# DIG - ANY Query

```python
dig any inlanefreight.htb @10.129.14.128

; <<>> DiG 9.16.1-Ubuntu <<>> any inlanefreight.htb @10.129.14.128
;; global options: +cmd
;; Got answer:
;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 7649
;; flags: qr aa rd ra; QUERY: 1, ANSWER: 5, AUTHORITY: 0, ADDITIONAL: 2

;; OPT PSEUDOSECTION:
; EDNS: version: 0, flags:; udp: 4096
; COOKIE: 064b7e1f091b95120100000061476865a6026d01f87d10ca (good)
;; QUESTION SECTION:
;inlanefreight.htb.             IN      ANY

;; ANSWER SECTION:
inlanefreight.htb.      604800  IN      TXT     "v=spf1 include:mailgun.org include:_spf.google.com include:spf.protection.outlook.com include:_spf.atlassian.net ip4:10.129.124.8 ip4:10.129.127.2 ip4:10.129.42.106 ~all"
inlanefreight.htb.      604800  IN      TXT     "atlassian-domain-verification=t1rKCy68JFszSdCKVpw64A1QksWdXuYFUeSXKU"
inlanefreight.htb.      604800  IN      TXT     "MS=ms97310371"
inlanefreight.htb.      604800  IN      SOA     inlanefreight.htb. root.inlanefreight.htb. 2 604800 86400 2419200 604800
inlanefreight.htb.      604800  IN      NS      ns.inlanefreight.htb.

;; ADDITIONAL SECTION:
ns.inlanefreight.htb.   604800  IN      A       10.129.34.136

;; Query time: 0 msec
;; SERVER: 10.129.14.128#53(10.129.14.128)
;; WHEN: So Sep 19 18:42:13 CEST 2021
;; MSG SIZE  rcvd: 437
```

Zone transfer refers to the transfer of zones to another server in DNS, which generally happens over TCP port 53. This procedure is called Asynchronous Full Transfer Zone (==AXFR==). Synchronization between the servers involved is realized by zone transfer. Using a secret key ==rndc-key==, we have seen this earlier in the default config, the servers make sure to communicate with their own master or slave. 

Original data of a zone is located on a DNS server, this is the ==primary== name server for this zone. For security and redundancy, additional servers are installed which are called ==secondary== servers. For some TLDs, making zone files for the Second Level Domains accessible on at least two servers is mandatory. 

DNS entries are usually only created, modified, or deleted on the primary. This can be done by manually editing the related zone file or automatically by a dynamic update via a DB. 

A DNS server that serves as a direct source for synchronizing a zone file it called the ==master==.
A DNS server that obtains zone data from a master is called a ==slave==.

A primary is always a master while a secondary can be either a slave or a master.

The slave fetches the SOA record of the relevant zone from the master at certain intervals (refresh time). If the serial number of the SOA record of the master is greater than the slave, the data sets no longer match.

---
# DIG - AXFR Zone Transfer

```python
dig axfr inlanefreight.htb @10.129.14.128

; <<>> DiG 9.16.1-Ubuntu <<>> axfr inlanefreight.htb @10.129.14.128
;; global options: +cmd
inlanefreight.htb.      604800  IN      SOA     inlanefreight.htb. root.inlanefreight.htb. 2 604800 86400 2419200 604800
inlanefreight.htb.      604800  IN      TXT     "MS=ms97310371"
inlanefreight.htb.      604800  IN      TXT     "atlassian-domain-verification=t1rKCy68JFszSdCKVpw64A1QksWdXuYFUeSXKU"
inlanefreight.htb.      604800  IN      TXT     "v=spf1 include:mailgun.org include:_spf.google.com include:spf.protection.outlook.com include:_spf.atlassian.net ip4:10.129.124.8 ip4:10.129.127.2 ip4:10.129.42.106 ~all"
inlanefreight.htb.      604800  IN      NS      ns.inlanefreight.htb.
app.inlanefreight.htb.  604800  IN      A       10.129.18.15
internal.inlanefreight.htb. 604800 IN   A       10.129.1.6
mail1.inlanefreight.htb. 604800 IN      A       10.129.18.201
ns.inlanefreight.htb.   604800  IN      A       10.129.34.136
inlanefreight.htb.      604800  IN      SOA     inlanefreight.htb. root.inlanefreight.htb. 2 604800 86400 2419200 604800
;; Query time: 4 msec
;; SERVER: 10.129.14.128#53(10.129.14.128)
;; WHEN: So Sep 19 18:51:19 CEST 2021
;; XFR size: 9 records (messages 1, bytes 520)
```

If the admin used a subnet for the ==allow-transfer== option for testing or as a workaround solution or set it to ==any==, everyone would query the entire zone file at the DNS server. In addition, ==other zones can be queried which may even sho internal IP addresses and hostnames==. 

---
# DIG - AXFR Zone Transfer - Internal

```python
dig axfr internal.inlanefreight.htb @10.129.14.128

; <<>> DiG 9.16.1-Ubuntu <<>> axfr internal.inlanefreight.htb @10.129.14.128
;; global options: +cmd
internal.inlanefreight.htb. 604800 IN   SOA     inlanefreight.htb. root.inlanefreight.htb. 2 604800 86400 2419200 604800
internal.inlanefreight.htb. 604800 IN   TXT     "MS=ms97310371"
internal.inlanefreight.htb. 604800 IN   TXT     "atlassian-domain-verification=t1rKCy68JFszSdCKVpw64A1QksWdXuYFUeSXKU"
internal.inlanefreight.htb. 604800 IN   TXT     "v=spf1 include:mailgun.org include:_spf.google.com include:spf.protection.outlook.com include:_spf.atlassian.net ip4:10.129.124.8 ip4:10.129.127.2 ip4:10.129.42.106 ~all"
internal.inlanefreight.htb. 604800 IN   NS      ns.inlanefreight.htb.
dc1.internal.inlanefreight.htb. 604800 IN A     10.129.34.16
dc2.internal.inlanefreight.htb. 604800 IN A     10.129.34.11
mail1.internal.inlanefreight.htb. 604800 IN A   10.129.18.200
ns.internal.inlanefreight.htb. 604800 IN A      10.129.34.136
vpn.internal.inlanefreight.htb. 604800 IN A     10.129.1.6
ws1.internal.inlanefreight.htb. 604800 IN A     10.129.1.34
ws2.internal.inlanefreight.htb. 604800 IN A     10.129.1.35
wsus.internal.inlanefreight.htb. 604800 IN A    10.129.18.2
internal.inlanefreight.htb. 604800 IN   SOA     inlanefreight.htb. root.inlanefreight.htb. 2 604800 86400 2419200 604800
;; Query time: 0 msec
;; SERVER: 10.129.14.128#53(10.129.14.128)
;; WHEN: So Sep 19 18:53:11 CEST 2021
;; XFR size: 15 records (messages 1, bytes 664)
```

The individual ==A== records with the hostnames can also be found via a brute-force attack.

An option would be to execute a for-loop in bash that lists these entries and sends the respective query to the desired DNS server.

---
# Subdomain Brute Forcing

```python
for sub in $(cat /opt/useful/seclists/Discovery/DNS/subdomains-top1million-110000.txt);do dig $sub.inlanefreight.htb @10.129.14.128 | grep -v ';\|SOA' | sed -r '/^\s*$/d' | grep $sub | tee -a subdomains.txt;done

ns.inlanefreight.htb.   604800  IN      A       10.129.34.136
mail1.inlanefreight.htb. 604800 IN      A       10.129.18.201
app.inlanefreight.htb.  604800  IN      A       10.129.18.15
```

Another way is via a tool called ==DNSenum==.

```python
dnsenum --dnsserver 10.129.14.128 --enum -p 0 -s 0 -o subdomains.txt -f /opt/useful/seclists/Discovery/DNS/subdomains-top1million-110000.txt inlanefreight.htb

dnsenum VERSION:1.2.6

-----   inlanefreight.htb   -----


Host's addresses:
__________________



Name Servers:
______________

ns.inlanefreight.htb.                    604800   IN    A        10.129.34.136


Mail (MX) Servers:
___________________



Trying Zone Transfers and getting Bind Versions:
_________________________________________________

unresolvable name: ns.inlanefreight.htb at /usr/bin/dnsenum line 900 thread 1.

Trying Zone Transfer for inlanefreight.htb on ns.inlanefreight.htb ...
AXFR record query failed: no nameservers


Brute forcing with /home/cry0l1t3/Pentesting/SecLists/Discovery/DNS/subdomains-top1million-110000.txt:
_______________________________________________________________________________________________________

ns.inlanefreight.htb.                    604800   IN    A        10.129.34.136
mail1.inlanefreight.htb.                 604800   IN    A        10.129.18.201
app.inlanefreight.htb.                   604800   IN    A        10.129.18.15
ns.inlanefreight.htb.                    604800   IN    A        10.129.34.136
```