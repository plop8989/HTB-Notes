
-Pn: disable ICMP echo requests
  -sA: Perform ACK scan on specified ports
  -sS: Perform SYN scan on specified ports
  -sn: Disables port scanning
  -iL: Scans against addresses in a hosts list [sudo nmap x y z -iL hosts.txt]
  -oA: Outputs results to specified file [sudo nmap x y z -oA host.txt]
  -PE: Performs scan using ICMP Echo Requests against the target
  --packet-trace: Shows all packets sent and received
  --reason: Displays the reason for a specific result
  --disable-arp-ping
  --stats-every=Xs: shows scan stats every X seconds
  -v / -vv: shows open ports directly when they are detected
  -A: Aggressive scan that uses -sV -O --traceroute and default
      NSE scripts.
  --Vuln: uses scripts from the vulnerabilities scanner category
  -F: Scans top 100 ports
  -D: Decoy scan (insert fake IPs inter IP headers)
  RND:X : Create X amount of IPs [ -D RND: 5]
  -f: (lowercase F). Fragment the packets. Default size 8 bytes
  -O: Performs OS scan
  -S: Scans target using different source IP addr [-S x.x.x.x]
  -e: Sends all requests through specified interface [-e tun0]
  --dns-server <ns>, <ns>: specifiy dns servers
  --source-port: specify source port of scan
  -g: shorthand for source port
  --min-rate x: minimum amount of packets sent per second. wouldn't recommend for stealth but up to 3000 seems to be stable for machines without firewall or IDS/IPS