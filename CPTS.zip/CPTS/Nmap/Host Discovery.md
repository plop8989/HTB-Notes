
Some firewalls don't allow scans and evasive techniques are needed

First step is to determine if the host is alive. 

By disabling port scanning nmap automatically pings the host with ICMP echo requests. 

If the host is alive we will get the same type of ping as a reply.

We can also achieve the same result using --reason.

Nmap will also determin if the host is alive using ARP pings.

ARP pinging can be disabled and ICMP can be used instead