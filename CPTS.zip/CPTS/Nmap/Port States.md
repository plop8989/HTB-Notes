
- ==Open==:    Indicates the connection to the port has been established.  These can be TCP , UDP datagrams , SCTP associations

- ==Closed==:    Indicates the packet we received has an RST flag

- ==Filtered==:    Nmap cannot identify whether the port is open or closed due to either an error code or no response		

- ==Unfiltered==: This state only occurs during a TCP-ACK scan. Port is accessible, but cannot be determined if its open or closed.

- ==Open | Filtered==:	If a port doesn't give us a response, Nmap will set it to that state.  Indicates that a firewall or packet filter may protect the port.

- ==Closed | Filtered==:	This only occurs in  IP ID Idle scans. Indicates it was impossible to determine if the port is closed or filtered by a firewall.
