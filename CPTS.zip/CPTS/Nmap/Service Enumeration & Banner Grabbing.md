
# Service Enumeration

We need to determine the application and its version as accurately as possible so we can look for known exploits

An initial quick port scan is useful to see available ports. This causes less traffic which is good as otherwise the security mechanisms can discover and block us

---
# Banner Grabbing

After a completed 3-way handshake, the server often sends a banner for identification to let the client know what service its working with. This is a PSH flag in the TCP header. Sometimes its not immediately provided or the info can be removed or manipulated.


We can manually connect to the SMTP server with NC, grab the banner, and intercept the network traffic using TCPDUMP, we can see what Nmap didnt show us. TCPDUMP: sudo tcpdump -i eth0 host <our ip> and <target ip>. Netcat: nc -nv <target ip>
